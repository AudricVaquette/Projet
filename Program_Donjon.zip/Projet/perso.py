from monstre import *
from donjon import *

class Personnage:
    def __init__(self,vitesse=5, attaque=5,pv=5,x=0,y=0):
        """Constructeur de la class personnage.
        
        paramètre valeur: les stats des personnage 
        renvoie: None
        """
    
        self.__vitesse=vitesse
        self.__attaque=attaque
        self.__pv=pv
        self.__x=x
        self.__y=y
        
    def get_vitesse(self):
        """Permet de recupérer les vitesses.
        Exemple:
        >>> h=Personnage()
        >>> h.get_vitesse()
        5
        """
        return self.__vitesse
    
    def get_attaque(self):
        """Permet de recupérer les attaques.
        Exemple:
        >>> h=Personnage()
        >>> h.get_attaque()
        5
        """
        return self.__attaque
    
    def get_pv(self):
        """Permet de recupérer les pv.
        Exemple:
        >>> h=Personnage()
        >>> h.get_pv()
        5
        """
        return self.__pv
    
    def get_x(self):
        """Permet de recupérer les coordonnées de x.
        Exemple:
        >>> h=Personnage()
        >>> h.get_x()
        0
        """
        return self.__x
        
    def get_y(self):
        """Permet de recupérer les coordonnées de y.
        Exemple:
        >>> h=Personnage()
        >>> h.get_y()
        0
        """
        return self.__y    
         
    def set_vitesse(self,n_vitesse):
        """Permet de changer la vitesse du personnage.
        Exemple:
        >>> h=Personnage()
        >>> h.set_vitesse(5)
        >>> h.get_vitesse()
        10
        """
        self.__vitesse = n_vitesse +self.__vitesse
        
    def set_attaque(self,n_attaque):
        """Permet de changer l'attaque du personnage.
        Exemple:
        >>> h=Personnage()
        >>> h.set_attaque(6)
        >>> h.get_attaque()
        11
        """
        self.__attaque = n_attaque + self.__attaque
   
    def set_pv(self,n_pv):
        """Permet de changer les pv du personnage.
        Exemple:
        >>> h=Personnage()
        >>> h.get_pv()
        5
        >>> h.set_pv(2)
        >>> h.get_pv()
        2
        """
        self.__pv = n_pv
    
    def set_x(self,n_x):
        """Permet de changer les pv du personnage.
        Exemple:
        >>> h=Personnage()
        >>> h.set_x(4)
        >>> h.get_x()
        4
        
        
        """
        self.__x = n_x + self.__x
    
    def set_y(self,n_y):
        """Permet de changer les pv du personnage.
        Exemple:
        >>> h=Personnage()
        >>> h.set_y(5)
        >>> h.get_y()
        5
        """
        self.__y = n_y + self.__y
    
    def degat_subit_h(self,monstre):
        """Retire à la vie du monstre la puissance d'attaque du hero.
        >>> h= Personnage(4,2,5,0,0)
        >>> m= Monstre(5,2,3,1,15)
        >>> m.get_pv()
        3
        >>> m.degat_subit_m(h)
        >>> m.get_pv()
        1
        """
        self.set_pv(self.get_pv()-monstre.get_attaque())
    
    
    
    
    def deplacement_joueur(self,etage):
        verif = True
        x=self.get_x()
        y=self.get_y()
        nombre=[]
        for i in range(-10,10):
            nombre.append(str(i))
        while verif:
            verif_2 = True
            
            while verif_2:
                mouvement_x =input("de combien en longueur")
                mouvement_y = input("de combien en largeur")
                if mouvement_x in nombre and mouvement_y in nombre:
                    mouvement_x = int(mouvement_x)
                    mouvement_y = int(mouvement_y)
                    verif_2 = False
                else:
                    print("ce n'est pas une valeur valide")
            if (self.get_x()+mouvement_x>=0 and self.get_x()+mouvement_x<len(etage.liste[0]))\
                or (self.get_y()+mouvement_y>=0 and self.get_y()+mouvement_y<len(etage.liste)):
                    if etage.liste[y+mouvement_y][x+mouvement_x] == " " :
                        
                        if abs(mouvement_x) + abs(mouvement_y) <= self.get_vitesse():
                            verif = False
                    else:
                        print("la case est occupé")
            else:
                print("Vous vous déplacer de trop de cases ou la case n'est pas valide")
                
        self.set_x(mouvement_x)
        self.set_y(mouvement_y)

                
                
if __name__ == '__main__':
   import doctest
   doctest.testmod(verbose=False)