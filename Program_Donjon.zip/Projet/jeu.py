# -*- coding: utf-8 -*-
"""
Created on Tue Oct 24 20:02:46 2023

@author: quentin
"""
from monstre import *
from donjon import *
from perso import *
import time

def jeu():
    hero=Personnage()
    reussi = True
    
    etage_2= Niveau([[" "," ","W","W","W","W","W","W"],
                     [" "," "," "," "," "," "," ","W"],
                     [" "," "," "," "," "," "," ","P"],
                     [" "," "," "," "," "," "," "," "]])
    
    etage_3 = Niveau([[" "," "," ","P","W","W","W","W"],
                     [" "," "," "," "," "," "," "," "],
                     [" "," "," "," "," "," ","W","W"]])
    
    
    etage_4 = Niveau([[" "," "," "," "," "," "," "," "," "," ","W"],
                     [" "," "," "," "," "," "," "," "," "," ","W"],
                     [" "," "," "," "," "," "," "," "," "," ","W"],
                     [" "," "," "," "," "," "," "," "," "," ","P"],
                     [" "," "," "," "," "," "," "," "," "," ","W"]])
    
    etage_5 = Niveau([["P"," "," "," "," "," "," ","W","W","W","W"],
                     [" "," "," "," "," "," "," "," ","W","W","W"],
                     [" "," "," "," "," "," "," "," "," ","W","W"],
                     [" "," "," "," "," "," "," "," "," "," ","W"],
                     [" "," "," "," "," "," "," "," "," "," "," "]])
    
    print("Bienvenue,\nVous êtes un héros qui doit finir le donjon.\n")
    time.sleep(0.5)
    print("le but est de finir le donjon en tuant ce boss." )
    regle=input("Si vous voulez les règles écrivez : oui")
    if regle=="oui":
        regles()
    etage_5.donjon(hero, Monstre(5,10,30,5,0,0))
    time.sleep(5)
    print("Vous êtes mort\nvous recommencer du début")
    
    while reussi:
        etage_2.donjon(hero, Monstre(4,2,7,7,3,2))
        
        if hero.get_pv()>0:    
            etage_2.fin_etage(hero,Monstre(0,0,1,7,2,0))
        
            etage_3.donjon(hero, Monstre(3,3,8,7,1,2))
            etage_3.donjon(hero, Monstre(5,3,9,5,2,2))
            if hero.get_pv()>0:
                etage_3.fin_etage(hero,Monstre(0,0,1,4,0,0))
             
                etage_4.donjon(hero, Monstre(6,4,11,9,0,2))
                etage_4.donjon(hero, Monstre(8,2,16,9,1,2))
                etage_4.donjon(hero, Monstre(4,5,14,1,0,3))
             
                if hero.get_pv()>0:
                    etage_4.fin_etage(hero,Monstre(0,0,1,10,2,0))
                    
                    etage_5.donjon(hero, Monstre(4,4,9,5,4,2))
                    etage_5.donjon(hero, Monstre(6,5,11,6,4,2))
                    etage_5.donjon(hero, Monstre(7,5,12,1,2,2))
                    etage_5.donjon(hero, Monstre(9,2,17,8,1,3))
                    etage_5.donjon(hero, Monstre(5,7,18,3,1,3))
                    etage_5.donjon(hero, Monstre(4,10,30,5,0,0))
                
                    if hero.get_pv()>0:
                        etage_5.fin_etage(hero,Monstre(0,0,1,10,2,0))
                        if hero.get_pv()>0:
                            print("\n\nBien joué vous avez réussi à sortir")
                            reussi = False
                        else:
                            time.sleep(4)
                            print("Vous êtes mort\nvous recommencer du début")
                    else:
                        time.sleep(3)
                        print("Vous êtes mort\nvous recommencer du début")
                else:
                    time.sleep(2)
                    print("Vous êtes mort\nvous recommencer du début")  
            else:
                time.sleep(2)
                print("Vous êtes mort\nvous recommencer du début")  
        hero = Personnage()
    


def regles():
    print("Vous vous promeniez dans la forêt quand vous êtes tomber dans un trou\n")
    time.sleep(1)      
    print("Vous vous réveiller et vous retrouver face un monstre, il ne vous a pas repéré"\
          "\ndès que vous bougez le monstre bouge aussi"\
              "\nvous savez que vous avez :\n"\
                "-points de vie:5\n-attaque:5\n-vitesse de deplacement:5\n"\
                    "Pour sortir il vous faut tuer les monstres qui vous donnent des clées pour dévérouiller les portes"\
                        "\nLes monstres ont des pv, attaque, et une vitesse de déplacement propre à chacun "\
                            "\nvous pouvez augmenter vos stat en tuant des monstres")
    print("les monstres peuvent détruire les décors mais pas vous"\
          "\nLes vitesses de déplacements servent à savoir de combien de cases se déplacer et "\
              "pour savoir qui attaque en premier.")
                            
    
    print("\nVous supposez que puisque vous n'avez pas bouger, vous êtes à l'étage le plus près de la sortie")
    
    
    
jeu()

    
    
    

    
    
    
    
    