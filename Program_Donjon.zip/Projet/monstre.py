from perso import *
from donjon import *

class Monstre:
    def __init__(self,vitesse, attaque,pv,x,y,stat):
        """Constructeur de la class monstre.
        
        paramètre valeur: les stats des monstre.
        renvoie: None
        """
    
        self.__vitesse=vitesse
        self.__attaque=attaque
        self.__pv=pv
        self.__x=x
        self.__y=y
        self.__stat=stat
    def get_vitesse(self):
        """Permet de recupérer les vitesses.
        Exemple:
        >>> m=Monstre(3,3,5,2,0)
        >>> m.get_vitesse()
        3
        """
        return self.__vitesse
    
    def get_attaque(self):
        """Permet de recupérer les attaques.
        Exemple:
        >>> m=Monstre(3,3,5,2,0)
        >>> m.get_attaque()
        3
        """
        return self.__attaque
    
    def get_pv(self):
        """Permet de recupérer les pv.
        Exemple:
        >>> m=Monstre(3,3,5,2,0)
        >>> m.get_pv()
        5
        """
        return self.__pv
    
    def get_x(self):
        """Permet de recupérer les coordonnées de x.
        Exemple:
        >>> m=Monstre(3,3,5,2,0)
        >>> m.get_x()
        2
        """
        return self.__x
        
    def get_y(self):
        """Permet de recupérer les coordonnées de y.
        Exemple:
        >>> m=Monstre(3,3,5,2,0)
        >>> m.get_y()
        0
        """
        return self.__y   
    
    def get_stat(self):
        return self.__stat
         
    def set_pv(self,n_pv):
        """Permet de changer les pv du personnage.
        Exemple:
        >>> m=Monstre(3,3,5,2,0)
        >>> m.set_pv(2)
        >>> m.get_pv()
        2
        """
        self.__pv = n_pv
        
    def set_vitesse(self):
        self.__vitesse = 0
    
    def set_x(self,n_x):
        """Permet de changer les pv du personnage.
        Exemple:
        >>> m=Monstre(3,3,5,2,0)
        >>> m.get_x()
        2
        >>> m.set_x(4)
        >>> m.get_x()
        6
        """
        self.__x = n_x + self.__x
    
    def set_y(self,n_y):
        """Permet de changer les pv du personnage.
        Exemple:
        >>> m=Monstre(3,3,5,2,0)
        >>> m.get_y()
        0
        >>> m.set_y(5)
        >>> m.get_y()
        5
        """
        self.__y = n_y + self.__y
        
        
    def set_stat(self,n_stat):
        self.__stat-=n_stat
        
        
            
    def deplacement_monstre_en_x(self,hero,etage):
        """IA du monstre.
        Exemple:
        >>> h=Personnage(5,5,5,6,0)
        >>> m=Monstre(3,3,5,2,0)
        >>> m.get_x()
        2
        >>> m.deplacement_monstre_en_x(h)
        >>> m.get_x()
        5
        >>> h=Personnage(5,5,5,6,0)
        >>> m=Monstre(3,3,5,9,0)
        >>> m.get_x()
        9
        >>> m.deplacement_monstre_en_x(h)
        >>> m.get_x()
        7
        
        """
        distance= abs(hero.get_x() - self.get_x())
        mouvement= self.get_vitesse()
        if distance>mouvement:
            if self.get_x()>hero.get_x():# Monstre à droite du joueur
                if etage.liste[self.get_y()][self.get_x()-mouvement] == " " :
                    self.set_x(-1*mouvement)
            else:# Monstre à gauche joueur
                if etage.liste[self.get_y()][self.get_x()+mouvement] == " " :
                    self.set_x(mouvement)
            
        if distance<=mouvement:
            if self.get_x()<hero.get_x():# Monstre à gauche du joueur
                if etage.liste[self.get_y()][self.get_y()+mouvement-1] == " ":
                    self.set_x(distance-1)
            else:# Monstre à droite joueur
                if etage.liste[self.get_y()][self.get_y()-mouvement+1] == " ":
                    self.set_x((-1*distance)+1)
        
        
        
    def deplacement_monstre_en_y(self,hero,etage):
        """IA du monstre.
        Exemple:
        >>> h=Personnage(5,5,5,0,6)
        >>> m=Monstre(3,3,5,0,2)
        >>> m.get_y()
        2
        >>> m.deplacement_monstre_en_y(h)
        >>> m.get_y()
        5
        >>> h=Personnage(5,5,5,0,6)
        >>> m=Monstre(3,3,5,0,9)
        >>> m.get_y()
        9
        >>> m.deplacement_monstre_en_y(h)
        >>> m.get_y()
        7
        """
        hauteur= abs(hero.get_y() - self.get_y())
        mouvement= self.get_vitesse()
        if hauteur>mouvement:
            if self.get_y()>hero.get_y():# Monstre au-dessus du joueur
                if etage.liste[self.get_y()-mouvement][self.get_x()] == " ":
                    self.set_y(-1*mouvement)
            else:# Monstre en-dessous joueur
                if etage.liste[self.get_y()+mouvement][self.get_x()] == " " :
                    self.set_y(mouvement)
        if hauteur<=mouvement:
            if self.get_y()<hero.get_y():# Monstre en-dessous du joueur
                if etage.liste[self.get_y()+hauteur-1][self.get_x()] == " ":
                    self.set_y(hauteur-1)
            else:# Monstre au-dessus joueur
                if etage.liste[self.get_y()-hauteur][self.get_x()] == " ":
                    self.set_y(-hauteur)    
            
        
        
        
    def a_cote(self,hero):
        """Méthode permetant de vérifier si le monstre et autour du hero et donc si le hero
            peut attaque le monstre.
            paramètre: hero (coordonné x et y) et les coordonné x et y du monstre
            renvoie: bool
            >>> h= Personnage()
            >>> m= Monstre(5,2,3,1,15)
            >>> m.a_cote(h)
            False
            """
        if self.get_x()-hero.get_x() in [-1,0,1] \
            and self.get_y()-hero.get_y() in [-1,0,1] :
            return True
        else:
            return False
        
    
    def degat_subit_m(self,hero):
        """Retire à la vie du monstre la puissance d'attaque du hero.
        >>> h= Personnage(4,2,5,0,0)
        >>> m= Monstre(5,2,3,1,15)
        >>> m.get_pv()
        3
        >>> m.degat_subit_m(h)
        >>> m.get_pv()
        1
        """
        self.set_pv(self.get_pv()-hero.get_attaque())


if __name__ == '__main__':
   import doctest
   doctest.testmod(verbose=False)   