# -*- coding: utf-8 -*-
"""
Created on Thu Oct  5 15:06:25 2023

@author: quentinfolliard
"""
from perso import *
from monstre import *


class Niveau:
    def __init__(self, liste):
        self.liste = liste
        
    def donjon(self,hero,monstre):
        an_pv = hero.get_pv()
        cpt = 0
        b= self.liste

        while hero.get_pv()>0 and monstre.get_pv()>0:
            cpt+=1
            
            b[hero.get_y()][hero.get_x()]= "H"
            if b[monstre.get_y()][monstre.get_x()]!= "H":
                b[monstre.get_y()][monstre.get_x()]= "M"
            else:
                monstre.set_y(-1)
                b[monstre.get_y()][monstre.get_x()]= "M"
            for y in range (len(self.liste)):
                for x in range (len(self.liste[0])):
                    if self.liste[y][x] == "H":
                        self.liste[y][x] ="\U0001F9D4"
                    elif self.liste[y][x] == "M":
                        self.liste[y][x] = "\U0001F47E"
                    elif self.liste[y][x] == "W":
                        self.liste[y][x] = "\U000026F0"
                    elif self.liste[y][x] == "P":
                        self.liste[y][x] = "\U0001F6AA"
                          
            a=len(b)
            while a>0:
                print(a,end="  ")
                print("   ,".join(b[a-1]))
                a-=1
            b[hero.get_y()][hero.get_x()]= " "
            b[monstre.get_y()][monstre.get_x()]= " "
            
            hero.deplacement_joueur(self)
            
            monstre.deplacement_monstre_en_x(hero,self)   
            if monstre.get_y() != hero.get_y():
                monstre.deplacement_monstre_en_y(hero,self)
            
            
            if monstre.a_cote(hero):
                if hero.get_vitesse()>monstre.get_vitesse():
                    monstre.degat_subit_m(hero)
                    if not monstre.get_pv()<0:
                        hero.degat_subit_h(monstre)
                else:
                    hero.degat_subit_h(monstre)
                    if not hero.get_pv()<0:
                        monstre.degat_subit_m(hero)
            print ("le hero a :" + str(hero.get_pv())+"pv")
            print ("le monstre a :" + str(monstre.get_pv())+"pv")
        
        if hero.get_pv()<=0:
            print("Vous avez perdu")
        else:
            print("Vous avez battu le monstre")
            while monstre.get_stat()>0:
                hero.set_pv(an_pv)
                n=input("Quelle stat voulez-vous améliorer(attaque pour l'attaque, vitesse pour la vitesse et pv pour la vie) ?")
                if n == 'attaque' :
                    hero.set_attaque(1)
                    print("La nouvelle attaque est de ",hero.get_attaque())
                    monstre.set_stat(1)
                    
                elif n == 'vitesse':                   
                    hero.set_vitesse(1)
                    print("La nouvelle vitesse est de ",hero.get_vitesse())
                    monstre.set_stat(1)
                    
                elif n== 'pv':
                    hero.set_pv(an_pv + 1)
                    print("Les nouveaux pv sont de ",hero.get_pv())
                    monstre.set_stat(1)
                    an_pv+=1
                else:
                    print("Ce n'est pas une stat disponible.")
    def fin_etage(self,hero,porte):
        cpt=0
        b= self.liste
        while hero.get_pv()>0 and porte.get_pv()>0:
            cpt+=1
            
            b[hero.get_y()][hero.get_x()]= "H"
            for y in range (len(self.liste)):
                for x in range (len(self.liste[0])):
                    if self.liste[y][x] == "H":
                        self.liste[y][x] ="\U0001F9D4"
                    elif self.liste[y][x] == "W":
                        self.liste[y][x] = "\U0001FAA8"
                    elif self.liste[y][x] == "P":
                        self.liste[y][x] = "\U0001F6AA"
                          
            a=len(b)
            while a>0:
                print(a,end="  ")
                print("   ,".join(b[a-1]))
                a-=1
            b[hero.get_y()][hero.get_x()]= " "
            hero.deplacement_joueur(self)
            if porte.a_cote(hero):                    
                porte.degat_subit_m(hero) 
        print("vous passez à l'étage suivant")
        hero.set_x(-hero.get_x())
        hero.set_y(-hero.get_y())
        
        
           
            
            
                   
        
            
        
""" ex : >>>a=Niveau([[" "," "," "," "," "," "],[" "," "," "," "," "," "],[" "," "," "," "," "," "]])
        >>>a.donjon(Personnage(),Monstre(3,3,5,4,0))
        3    ,    ,   ,   ,    ,
        2    ,    ,   ,   ,    ,
        1M   ,    ,   ,   ,M   ,
"""        